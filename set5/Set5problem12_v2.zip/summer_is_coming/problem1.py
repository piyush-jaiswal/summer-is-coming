from summer_is_coming.golden_crown import GoldenCrownFactory


def main():
    GoldenCrownFactory.get("shan").conquer()


if __name__ == '__main__':
    main()
