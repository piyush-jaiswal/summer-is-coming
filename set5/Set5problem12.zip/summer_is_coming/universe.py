from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import field, dataclass
from functools import partial

from sortedcontainers import SortedKeyList, SortedList

from summer_is_coming.kingdom import Kingdom


@dataclass
class Universe:
    name: str
    _kingdoms: SortedKeyList[Kingdom] = field(
        default_factory=partial(SortedKeyList, key=lambda x: x.name), init=False
    )
    _ruler: str = field(default="", init=False)
    _allies: SortedList[str] = field(default_factory=SortedList, init=False)

    def __post_init__(self):
        self.name = self.name.capitalize()

    @property
    def kingdoms(self) -> SortedKeyList[Kingdom]:
        return self._kingdoms

    @property
    def ruler(self) -> str:
        return self._ruler

    @ruler.setter
    def ruler(self, new_ruler: str):
        new_ruler = new_ruler.capitalize()
        self.get_kingdom(new_ruler)
        self._ruler = new_ruler

    @property
    def allies(self) -> SortedList[str]:
        return self._allies

    @staticmethod
    def sorted_list_get_with_key(sorted_list: SortedKeyList, key: object) -> object:
        idx = sorted_list.bisect_key_left(key)
        if idx < len(sorted_list) and sorted_list.key(sorted_list[idx]) == key:
            return sorted_list[idx]
        else:
            raise ValueError(
                "key '{}' not present in sorted list '{}'".format(key, sorted_list)
            )

    @staticmethod
    def _is_worthy_ally(kingdom: Kingdom, msg: str):
        # Memory and time efficient way. Time Complexity: O(nlogn)
        i = 0
        j = 0
        emblem = sorted(kingdom.emblem.lower())
        msg = sorted(msg.lower())
        while i < len(emblem):
            alpha = emblem[i]
            emblem_start_pos = bisect_left(emblem, alpha, lo=i)
            emblem_end_pos = bisect_right(emblem, alpha, lo=i)

            msg_start_pos = bisect_left(msg, alpha, lo=j)
            msg_end_pos = bisect_right(msg, alpha, lo=j)

            if (msg_end_pos - msg_start_pos) < (emblem_end_pos - emblem_start_pos):
                return False

            i = emblem_end_pos
            j = msg_end_pos

        return True

        # If memory and time is not an issue, we can use this. Time Complexity: O(n^2)
        #
        # is_worthy = all([msg.count(alpha) >= count for alpha, count in Counter(kingdom.emblem)])
        # return is_worthy

    # This takes in pledgee and pledger as strings, rather than kingdoms to make sure the allegiances formed are between
    # the objects that belong to this universe.
    def form_allegiance(self, pledgee: str, pledger: str, msg: str) -> bool:
        pledgee_kingdom = self.get_kingdom(pledgee)
        pledger_kingdom = self.get_kingdom(pledger)

        is_worthy = self._is_worthy_ally(pledger_kingdom, msg)
        if is_worthy:
            pledger_kingdom._ally = pledgee_kingdom

        return is_worthy

    def get_kingdom(self, kingdom_name: str) -> Kingdom:
        kingdom_name = kingdom_name.capitalize()
        try:
            kingdom = self.sorted_list_get_with_key(self._kingdoms, kingdom_name)
        except ValueError:
            raise ValueError(
                "Kingdom '{}' is not part of the '{}' universe".format(
                    kingdom_name, self.name
                )
            )

        return kingdom

    def add_kingdom(self, kingdom: Kingdom) -> Universe:
        if kingdom not in self._kingdoms:
            self._kingdoms.add(kingdom)
        return self

    def add_ally(self, ally: str) -> Universe:
        ally = ally.capitalize()
        self.get_kingdom(ally)
        if ally not in self._allies:
            self._allies.add(ally)

        return self
