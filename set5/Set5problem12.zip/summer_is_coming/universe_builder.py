from abc import ABC, abstractmethod

from summer_is_coming.kingdom import Kingdom
from summer_is_coming.universe import Universe


class UniverseBuilder(ABC):
    @abstractmethod
    def build(self) -> Universe:
        pass


class SoutherosBuilder(UniverseBuilder):
    @staticmethod
    def build(self=None) -> Universe:
        return (
            Universe("Southeros")
            .add_kingdom(Kingdom(name="Space", emblem="Gorilla"))
            .add_kingdom(Kingdom(name="Land", emblem="Panda"))
            .add_kingdom(Kingdom(name="Water", emblem="Octopus"))
            .add_kingdom(Kingdom(name="Fire", emblem="Dragon"))
            .add_kingdom(Kingdom(name="Air", emblem="Owl"))
            .add_kingdom(Kingdom(name="Ice", emblem="Mammoth"))
        )
