import itertools
import random
from dataclasses import dataclass, field
from os import path
from typing import List, Iterable

from num2words import num2words
from sortedcontainers import SortedKeyList

from summer_is_coming.kingdom import Kingdom
from summer_is_coming.universe import Universe
from summer_is_coming.universe_builder import SoutherosBuilder

MSG_FILE_PATH = path.join(path.dirname(__file__), "boc_messages.txt")


@dataclass(order=True)
class BOCKingdom:
    kingdom: Kingdom
    is_competing: bool = field(default=False, init=False)
    ally_count: int = field(default=0, init=False)


@dataclass
class BallotMessage:
    receiver: BOCKingdom
    sender: BOCKingdom
    msg: str


def show_ruler_and_allies(universe: Universe):
    ruler = universe.ruler if universe.ruler else "None"
    allies = ", ".join(universe.allies) if universe.allies else "None"

    print()
    print("Who is the ruler of {}?".format(universe.name))
    print("Output:", ruler)
    print("Allies of Ruler?")
    print("Output:", allies)
    print()


def set_ruler_and_allies(universe: Universe, ruler: str):
    universe.ruler = ruler
    for kingdom in universe.kingdoms:
        if kingdom.ally and kingdom.ally.name == ruler:
            universe.add_ally(kingdom.name)


def show_ballot_result(kingdoms: Iterable[BOCKingdom], round_count: int):
    print("Results after round {} ballot count".format(num2words(round_count)))
    for boc_kingdom in kingdoms:
        if boc_kingdom.is_competing:
            print(
                "Output: Allies for {}: {}".format(
                    boc_kingdom.kingdom.name, boc_kingdom.ally_count
                )
            )


def update_competing_kingdoms(kingdoms: Iterable[BOCKingdom]):
    max_allies = max([kingdom.ally_count for kingdom in kingdoms])

    # Assumption: Previously competing kingdom which won't be competing now can form allegiances
    for kingdom in kingdoms:
        if kingdom.ally_count != max_allies:
            kingdom.is_competing = False


def get_competing_kingdoms(kingdoms: SortedKeyList) -> SortedKeyList:
    return SortedKeyList(
        [kingdom for kingdom in kingdoms if kingdom.is_competing], key=kingdoms.key
    )


def get_ballot_messages(
    kingdoms: SortedKeyList, messages: List[str], samples: int = 6
) -> List[BallotMessage]:
    competing_kingdoms = get_competing_kingdoms(kingdoms)
    ballot_messages = [
        BallotMessage(receiver, sender, random.choice(messages))
        for receiver, sender in itertools.product(kingdoms, competing_kingdoms)
        if receiver is not sender
    ]
    return random.sample(ballot_messages, min(len(ballot_messages), samples))


def read_messages(path: str) -> List[str]:
    with open(path, "r") as f:
        return [msg.strip(",") for msg in f.read().splitlines()]


def get_boc_kingdoms(
    universe: Universe, competing_kingdom_names: Iterable[str]
) -> SortedKeyList:
    kingdoms = SortedKeyList(
        [BOCKingdom(kingdom) for kingdom in universe.kingdoms],
        key=lambda x: x.kingdom.name,
    )

    for kingdom_name in competing_kingdom_names:
        kingdom = universe.sorted_list_get_with_key(kingdoms, key=kingdom_name)
        kingdom.is_competing = True

    return kingdoms


def reset_allies(boc_kingdoms: Iterable[BOCKingdom]):
    for boc_kingdom in boc_kingdoms:
        boc_kingdom.ally_count = 0
        boc_kingdom.kingdom.reset_ally()


def conduct_ballot(universe: Universe, competing_kingdom_names: Iterable[str]) -> str:
    messages = read_messages(MSG_FILE_PATH)
    kingdoms = get_boc_kingdoms(universe, competing_kingdom_names)

    round_count = 1
    while len(get_competing_kingdoms(kingdoms)) > 1:
        reset_allies(kingdoms)
        ballot_messages = get_ballot_messages(kingdoms, messages)

        for msg in ballot_messages:
            if not msg.receiver.is_competing and msg.receiver.kingdom.ally is None:
                if universe.form_allegiance(
                    msg.sender.kingdom.name, msg.receiver.kingdom.name, msg.msg
                ):
                    msg.sender.ally_count += 1

        show_ballot_result(kingdoms, round_count)
        update_competing_kingdoms(kingdoms)
        round_count += 1

    return get_competing_kingdoms(kingdoms)[0].kingdom.name


def process_input() -> List[str]:
    print("Enter the kingdoms competing to be the ruler:")
    inp = input("Input: ")
    print()
    kingdom_names = [name.strip().capitalize() for name in inp.split()]
    if not kingdom_names:
        raise ValueError("Please enter space separated kingdoms")

    return kingdom_names


def main():
    southeros = SoutherosBuilder.build()
    show_ruler_and_allies(southeros)
    kingdom_names = process_input()
    ruler = conduct_ballot(southeros, kingdom_names)
    set_ruler_and_allies(universe=southeros, ruler=ruler)
    show_ruler_and_allies(southeros)


if __name__ == "__main__":
    main()
