from summer_is_coming.universe import Universe
from summer_is_coming.universe_builder import SoutherosBuilder


def show_ruler_and_allies(universe: Universe):
    ruler = "King Shan" if universe.ruler else "None"
    allies = ", ".join(universe.allies) if universe.allies else "None"

    print("Who is the ruler of Southeros?")
    print("Output:", ruler)
    print("Allies of Ruler?")
    print("Output:", allies)
    print()


def process_input(user_input: str) -> (str, str):
    kingdom_name, msg = user_input.split(",")
    kingdom_name = kingdom_name.strip()
    msg = msg.strip()
    msg = msg.strip('"')

    return kingdom_name, msg


def set_ruler_and_allies(universe: Universe, ruler: str):
    universe.ruler = ruler
    for kingdom in universe.kingdoms:
        if kingdom.ally and kingdom.ally.name == ruler:
            universe.add_ally(kingdom.name)


def main():
    southeros = SoutherosBuilder.build()
    show_ruler_and_allies(southeros)
    n = int(input("No of messages: "))
    print("Input Messages to kingdoms from King Shan:")

    inputs = [process_input(input("Input: ")) for _ in range(n)]
    allegiances = [
        southeros.form_allegiance(pledgee="Space", pledger=pledger, msg=msg)
        for pledger, msg in inputs
    ]
    print()

    if allegiances.count(True) >= 3:
        set_ruler_and_allies(universe=southeros, ruler="Space")

    show_ruler_and_allies(southeros)


if __name__ == "__main__":
    main()
