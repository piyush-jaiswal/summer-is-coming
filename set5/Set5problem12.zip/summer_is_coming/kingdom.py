from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(order=True)
class Kingdom:
    name: str
    emblem: str

    # Type is a kingdom rather then str to accomodate for changes later, like getting emblem of ally etc.
    _ally: Kingdom = field(default=None, init=False)

    def __post_init__(self):
        self.name = self.name.capitalize()
        self.emblem = self.emblem.capitalize()

    # Custom '__eq__' method despite of dataclasses, for the reason that two kingdoms with the same name and different emblems
    # will be considered equal. Hence they can belong in the same kingdoms, which should not be possible.
    def __eq__(self, other: Kingdom):
        return self.name == other.name

    @property
    def ally(self) -> Kingdom:
        return self._ally

    # Not allowed to set ally manually. Have to go through 'form_allegiance', hence no setter.
    def reset_ally(self):
        self._ally = None
