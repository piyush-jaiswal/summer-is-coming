import pytest
from sortedcontainers import SortedListWithKey

from summer_is_coming.kingdom import Kingdom
from summer_is_coming.universe import Universe


@pytest.fixture
def westeros():
    return (
        Universe("Westeros")
        .add_kingdom(Kingdom(name="Stark", emblem="Direwolf"))
        .add_kingdom(Kingdom(name="Lannister", emblem="Lion"))
    )


def test_ruler_setter(westeros):
    westeros.ruler = "stark"

    assert westeros.ruler == "Stark"
    with pytest.raises(ValueError):
        westeros.ruler = "targareyan"


def test_sorted_list_get_with_key():
    sorted_list = SortedListWithKey([(1, 3), (2, 2), (3, 1)], key=lambda x: x[1])
    assert Universe.sorted_list_get_with_key(sorted_list, 1) == (3, 1)
    assert Universe.sorted_list_get_with_key(sorted_list, 2) == (2, 2)
    with pytest.raises(ValueError):
        Universe.sorted_list_get_with_key(sorted_list, 10)


def test_form_allegiance(westeros):
    assert (
        westeros.form_allegiance(
            pledgee="Lannister", pledger="Stark", msg="Hand of King"
        )
        is False
    )
    assert westeros.form_allegiance(
        pledgee="Lannister", pledger="Stark", msg="Kill that direwolf!"
    )

    with pytest.raises(ValueError):
        assert westeros.form_allegiance(
            pledgee="Targareyan", pledger="Stark", msg="I have dragons!"
        )
        assert westeros.form_allegiance(
            pledgee="Stark", pledger="Targareyan", msg="I have Jon Snow :p"
        )


def test_get_kingdom_by_name(westeros):
    assert westeros.get_kingdom("Stark") == Kingdom(name="Stark", emblem="Direwolf")
    with pytest.raises(ValueError):
        assert westeros.get_kingdom("Targareyan")


def test_add_kingdom(westeros):
    targareyan = Kingdom(name="Targareyan", emblem="Dragons")
    assert len(westeros.kingdoms) + 1 == len(westeros.add_kingdom(targareyan).kingdoms)
    assert westeros.get_kingdom("Targareyan") == targareyan


def test_add_ally(westeros):
    westeros.add_ally("Stark")

    assert "Stark" in westeros.allies
    with pytest.raises(ValueError):
        assert westeros.add_ally("targareyan")
