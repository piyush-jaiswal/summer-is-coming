from summer_is_coming.kingdom import Kingdom


def test_equals_operator():
    kingdom = Kingdom(name="Land", emblem="paNda")
    kingdom2 = Kingdom(name="Air", emblem="owl")
    kingdom3 = Kingdom(name="Land", emblem="elephant")

    assert (kingdom == kingdom2) is False
    assert kingdom == kingdom3
