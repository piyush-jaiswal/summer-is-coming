import pytest

from summer_is_coming.a_golden_crown import process_input, set_ruler_and_allies
from summer_is_coming.kingdom import Kingdom
from summer_is_coming.universe import Universe


@pytest.fixture
def westeros():
    return (
        Universe("Westeros")
        .add_kingdom(Kingdom(name="Stark", emblem="Direwolf"))
        .add_kingdom(Kingdom(name="Lannister", emblem="Lion"))
    )


def test_process_input():
    assert process_input('Air, "oaaawaala"') == ("Air", "oaaawaala")
    assert process_input('Land, "a1d22n333a4444p"') == ("Land", "a1d22n333a4444p")


def test_set_ruler_and_allies(westeros):
    is_formed = westeros.form_allegiance(
        pledger="lannister", pledgee="stark", msg="lion"
    )
    set_ruler_and_allies(westeros, "Stark")

    assert is_formed
    assert westeros.ruler == "Stark"
    assert westeros.allies == ["Lannister"]
    with pytest.raises(ValueError):
        set_ruler_and_allies(westeros, "Targareyan")
