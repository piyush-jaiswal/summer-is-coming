import pytest
from sortedcontainers import SortedKeyList

from summer_is_coming.breaker_of_chains import (
    set_ruler_and_allies,
    BOCKingdom,
    get_competing_kingdoms,
    get_ballot_messages,
    get_boc_kingdoms,
    conduct_ballot,
    reset_allies,
    update_competing_kingdoms,
)
from summer_is_coming.kingdom import Kingdom
from summer_is_coming.universe import Universe


@pytest.fixture
def westeros():
    return (
        Universe("Westeros")
        .add_kingdom(Kingdom(name="Stark", emblem="Direwolf"))
        .add_kingdom(Kingdom(name="Lannister", emblem="Lion"))
        .add_kingdom(Kingdom(name="Targareyan", emblem="Dragon"))
    )


def test_set_ruler_and_allies(westeros):
    is_formed = westeros.form_allegiance(
        pledger="lannister", pledgee="stark", msg="lion"
    )
    set_ruler_and_allies(westeros, "Stark")

    assert is_formed
    assert westeros.ruler == "Stark"
    assert westeros.allies == ["Lannister"]
    with pytest.raises(ValueError):
        set_ruler_and_allies(westeros, "Tully")


def test_update_state(westeros):
    kingdoms = [BOCKingdom(kingdom) for kingdom in westeros.kingdoms]

    update_competing_kingdoms(kingdoms)
    assert (
        kingdoms[0].is_competing is False
        and kingdoms[1].is_competing is False
        and kingdoms[2].is_competing is False
    )

    kingdoms[0].is_competing = True
    kingdoms[1].is_competing = True
    kingdoms[0].ally_count = 2
    kingdoms[1].ally_count = 2

    update_competing_kingdoms(kingdoms)
    assert (
        kingdoms[0].is_competing is True
        and kingdoms[1].is_competing is True
        and kingdoms[2].is_competing is False
    )

    kingdoms[0].ally_count = 3
    update_competing_kingdoms(kingdoms)
    assert (
        kingdoms[0].is_competing is True
        and kingdoms[1].is_competing is False
        and kingdoms[2].is_competing is False
    )


def test_get_competing_kingdoms(westeros):
    kingdoms = SortedKeyList(
        [BOCKingdom(kingdom) for kingdom in westeros.kingdoms],
        key=lambda x: x.kingdom.name,
    )
    kingdoms[0].is_competing = True
    competing_kingdoms = get_competing_kingdoms(kingdoms)
    assert competing_kingdoms == SortedKeyList([kingdoms[0]])


def test_get_ballot_messages(westeros):
    kingdoms = SortedKeyList(
        [BOCKingdom(kingdom) for kingdom in westeros.kingdoms],
        key=lambda x: x.kingdom.name,
    )
    kingdoms[0].is_competing = True
    messages = ["test_msg1", "test_msg2"]

    ballot_messages = get_ballot_messages(kingdoms, messages, samples=2)
    receiving_kingdoms = [msg.receiver for msg in ballot_messages]
    sent_messages = [msg.msg for msg in ballot_messages]

    assert kingdoms[1] in receiving_kingdoms and kingdoms[2] in receiving_kingdoms
    assert "test_msg1" in sent_messages or "test_msg2" in sent_messages


def test_get_boc_kingdoms(westeros):
    competing_kingdom_names = ["Stark", "Targareyan"]
    boc_kingdoms = get_boc_kingdoms(westeros, competing_kingdom_names)
    assert all([isinstance(kingdom, BOCKingdom) for kingdom in boc_kingdoms])

    assert westeros.sorted_list_get_with_key(boc_kingdoms, "Stark").is_competing is True
    assert (
        westeros.sorted_list_get_with_key(boc_kingdoms, "Targareyan").is_competing
        is True
    )
    assert (
        westeros.sorted_list_get_with_key(boc_kingdoms, "Lannister").is_competing
        is False
    )


def test_reset_allies(westeros):
    kingdoms = SortedKeyList(
        [BOCKingdom(kingdom) for kingdom in westeros.kingdoms],
        key=lambda x: x.kingdom.name,
    )
    kingdoms[0].ally_count = 3
    allegiance1 = westeros.form_allegiance(
        pledger=kingdoms[1].kingdom.name,
        pledgee=kingdoms[0].kingdom.name,
        msg=kingdoms[1].kingdom.emblem,
    )

    kingdoms[1].ally_count = 2
    allegiance2 = westeros.form_allegiance(
        pledger=kingdoms[0].kingdom.name,
        pledgee=kingdoms[1].kingdom.name,
        msg=kingdoms[0].kingdom.emblem,
    )

    reset_allies(kingdoms)

    assert allegiance1 and allegiance2
    assert sum([kingdom.ally_count for kingdom in kingdoms]) == 0
    assert [boc_kingdom.kingdom.ally for boc_kingdom in kingdoms] == [None] * len(
        kingdoms
    )


def test_conduct_ballot(westeros):
    competing_kingdom_names = ["Stark"]
    winner = conduct_ballot(westeros, competing_kingdom_names)
    assert winner == "Stark"

    competing_kingdom_names = ["Stark", "Targareyan"]
    winner = conduct_ballot(westeros, competing_kingdom_names)
    assert winner == "Targareyan" or winner == "Stark"
